﻿Following are details about folders present in your downloaded package -

smart_school_src:			Main source code files required to install Smart School latest version 6.3.0.
smart_school_update_6.2.0_to_6.3.0:		Contains update package files for updating previous version 6.2.0 to new version 6.3.0.
documentation:							Quick Installation Guide & User’s Manual for understanding how Smart School works.
licensing:								GPL license files.

For help and support, feel free to contact us http://smart-school.in or open support ticket at our support portal http://support.qdocs.in or email us support@qdocs.in .

Thanks for using Smart School
QDOCS Team


Envato Username :
emai: otoneefrisks1986+Cervantes@gmail.com
user : Cervantes2312